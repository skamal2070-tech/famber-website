# FAMBER Website Starter
A responsive React + Vite starter interface for FAMBER.

## Run on your computer
1. Install Node.js (LTS) from https://nodejs.org/
2. Extract this ZIP.
3. Open the extracted folder in VS Code.
4. Open Terminal and run `npm install`.
5. Run `npm run dev` and open the local address shown in the terminal.

## Important
This is an initial UI starter, not a finished social network. Login, real profiles, persistent posts, media uploads, comments, follows, messaging, calls, games, watch-together, notifications and admin tools still need implementation and secure backend configuration. Demo posts and story circles are sample content. Do not collect real user data until authentication, database security and privacy settings have been properly configured.
