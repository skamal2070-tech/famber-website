# FAMBER setup (beginner guide)
- This ZIP is the website project source, not an app download.
- First extract it on your computer.
- To publish online, use a hosting service such as Vercel or Netlify; these services normally require an account.
- After publishing, you will receive a public URL such as `https://your-project-name.vercel.app`.
- Paste that public URL into PWABuilder.
- PWABuilder cannot build from a ZIP filename or a folder path. The site must be publicly reachable over HTTPS.
- Android builds can be prepared on Windows. Building an iOS app generally requires macOS and Xcode.
